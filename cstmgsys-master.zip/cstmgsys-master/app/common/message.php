<?php
/*
 * メッセージ
 */

const MSGI001 = '登録処理が完了しました。';
const MSGI002 = '更新処理が完了しました。';
const MSGI003 = '削除処理が完了しました。';
const MSGE001 = 'データ取得に失敗しました。';
const MSGE002 = '';
const MSGE003 = '';
const MSGW001 = '削除処理を実行します。よろしいですか？';
const MSGW002 = '';
const MSGW003 = '';
