<?php
/*
 * 定数
 */

const CUSTOMER_PERSON       = '個人';
const CUSTOMER_CORPORATE    = '法人';
const CUSTOMER_PERSON_ID    = '0';
const CUSTOMER_CORPORATE_ID = '1';
